
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

   
    
   
   
   
   



<div class="portfolio-item">
    <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal<?php echo e($proyecto->id); ?>">
        <div class="portfolio-hover">
            <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
        </div>
        <img class="img-fluid" src="<?php echo e($proyecto->imagen); ?>" alt="..." />
    </a>
    <div class="portfolio-caption">
        <div class="portfolio-caption-heading"><?php echo e($proyecto->nombre); ?></div>
        <div class="portfolio-caption-subheading text-muted"></div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal<?php echo e($proyecto->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-bs-dismiss="modal"><img src="" alt="Close modal" /></div>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-8">
                            <div class="modal-body">
                                <!-- Project details-->
                                <h2 class="text-uppercase"> <?php echo e($proyecto->nombre); ?></h2>
                                
                                <img class="img-fluid d-block mx-auto" src="<?php echo e($proyecto->imagen); ?>" alt="..." />
                                <p> <?php echo e($proyecto->descripcion); ?></p>
                               
                                <a href=" <?php echo e($proyecto->url); ?>" class="btn btn-primary btn-xl text-uppercase">
                                    <i class="fas fa-xmark me-1"></i>
                                    VISITAR
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tempplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\principal\resources\views/welcome.blade.php ENDPATH**/ ?>