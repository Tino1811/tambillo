<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="https://getbootstrap.com/docs/5.2/assets/css/docs.css"
      rel="stylesheet"
    />
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
  </head>
  <body class="p-3 m-0 border-0 bd-example">
    <!-- Example Code -->

    <div
      id="carouselExampleCaptions"
      class="carousel slide"
      data-bs-ride="false"
    >
      <div class="carousel-indicators">
        <button
          type="button"
          data-bs-target="#carouselExampleCaptions"
          data-bs-slide-to="0"
          class="active"
          aria-current="true"
          aria-label="Slide 1"
        ></button>
        <button
          type="button"
          data-bs-target="#carouselExampleCaptions"
          data-bs-slide-to="1"
          aria-label="Slide 2"
        ></button>
        <button
          type="button"
          data-bs-target="#carouselExampleCaptions"
          data-bs-slide-to="2"
          aria-label="Slide 3"
        ></button>
      </div>
      <div class="carousel-inner">
       
        <div class="carousel-item active">
          <svg
            class="bd-placeholder-img bd-placeholder-img-lg d-block w-100"
            width="800"
            height="400"
            xmlns="http://www.w3.org/2000/svg"
            role="img"
            aria-label="Placeholder: First slide"
            preserveAspectRatio="xMidYMid slice"
            focusable="false"
          >
            <title>Placeholder</title>
            
            <rect width="100%" height="100%" fill="#777"></rect>
            <text x="50%" y="50%" fill="#555" dy=".3em">First slide</text>
            
          </svg>

          <div class="carousel-caption d-none d-md-block">
            
            <h5>NOMBRE "TAMBILLO"</h5>
            <p>informacion de tambillo</p>
           
            
          </div>
        </div>
        <div class="carousel-item">
            <img src="/principal/img/danza.gif" class="card-img-top" alt="...">
          <svg
            class="bd-placeholder-img bd-placeholder-img-lg d-block w-100"
            width="800"
            height="400"
            xmlns="http://www.w3.org/2000/svg"
            role="img"
            aria-label="Placeholder: Second slide"
            preserveAspectRatio="xMidYMid slice"
            focusable="false"
          >
            <title>Placeholder</title>
            <rect width="100%" height="100%" fill="#666"></rect>
            <text x="50%" y="50%" fill="#444" dy=".3em">Second slide</text>
          </svg>

          <div class="carousel-caption d-none d-md-block">
            <h5>Second slide label</h5>
            <p>Some representative placeholder content for the second slide.</p>
          </div>
        </div>
        <div class="carousel-item">
          <svg
            class="bd-placeholder-img bd-placeholder-img-lg d-block w-100"
            width="800"
            height="400"
            xmlns="http://www.w3.org/2000/svg"
            role="img"
            aria-label="Placeholder: Third slide"
            preserveAspectRatio="xMidYMid slice"
            focusable="false"
          >
            <title>Placeholder</title>
            <rect width="100%" height="100%" fill="#555"></rect>
            <text x="50%" y="50%" fill="#333" dy=".3em">Third slide</text>
          </svg>

          <div class="carousel-caption d-none d-md-block">
            <h5>Third slide label</h5>
            <p>Some representative placeholder content for the third slide.</p>
          </div>
        </div>
      </div>
      <button
        class="carousel-control-prev"
        type="button"
        data-bs-target="#carouselExampleCaptions"
        data-bs-slide="prev"
      >
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button
        class="carousel-control-next"
        type="button"
        data-bs-target="#carouselExampleCaptions"
        data-bs-slide="next"
      >
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
    
     <!-- Portfolio Grid-->
     <section class="page-section bg-light" id="portfolio">
      <div class="container">
          <div class="text-center">
              <h2 class="section-heading text-uppercase">EMPRENDIMIENTOS</h2>
              
          </div>
          <div class="row">
              <div class="col-lg-4 col-sm-6 mb-4">
                  <!-- Portfolio item 1-->
                  <div class="portfolio-item">
                      <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal1">
                          <div class="portfolio-hover">
                              <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                          </div>
                          <img class="img-fluid" src="assets/img/portfolio/1.jpg" alt="..." />
                      </a>
                      <div class="portfolio-caption">
                          <div class="portfolio-caption-heading">Threads</div>
                          <div class="portfolio-caption-subheading text-muted">Illustration</div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 col-sm-6 mb-4">
                  <!-- Portfolio item 2-->
                  <div class="portfolio-item">
                      <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal2">
                          <div class="portfolio-hover">
                              <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                          </div>
                          <img class="img-fluid" src="assets/img/portfolio/2.jpg" alt="..." />
                      </a>
                      <div class="portfolio-caption">
                          <div class="portfolio-caption-heading">Explore</div>
                          <div class="portfolio-caption-subheading text-muted">Graphic Design</div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 col-sm-6 mb-4">
                  <!-- Portfolio item 3-->
                  <div class="portfolio-item">
                      <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal3">
                          <div class="portfolio-hover">
                              <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                          </div>
                          <img class="img-fluid" src="assets/img/portfolio/3.jpg" alt="..." />
                      </a>
                      <div class="portfolio-caption">
                          <div class="portfolio-caption-heading">Finish</div>
                          <div class="portfolio-caption-subheading text-muted">Identity</div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
                  <!-- Portfolio item 4-->
                  <div class="portfolio-item">
                      <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal4">
                          <div class="portfolio-hover">
                              <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                          </div>
                          <img class="img-fluid" src="assets/img/portfolio/4.jpg" alt="..." />
                      </a>
                      <div class="portfolio-caption">
                          <div class="portfolio-caption-heading">Lines</div>
                          <div class="portfolio-caption-subheading text-muted">Branding</div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 col-sm-6 mb-4 mb-sm-0">
                  <!-- Portfolio item 5-->
                  <div class="portfolio-item">
                      <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal5">
                          <div class="portfolio-hover">
                              <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                          </div>
                          <img class="img-fluid" src="assets/img/portfolio/5.jpg" alt="..." />
                      </a>
                      <div class="portfolio-caption">
                          <div class="portfolio-caption-heading">Southwest</div>
                          <div class="portfolio-caption-subheading text-muted">Website Design</div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 col-sm-6">
                  <!-- Portfolio item 6-->
                  <div class="portfolio-item">
                      <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal6">
                          <div class="portfolio-hover">
                              <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                          </div>
                          <img class="img-fluid" src="assets/img/portfolio/6.jpg" alt="..." />
                      </a>
                      <div class="portfolio-caption">
                          <div class="portfolio-caption-heading">Window</div>
                          <div class="portfolio-caption-subheading text-muted">Photography</div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </section>






 <!-- Left -->
 <hr class="hr hr-blurry" />
<!-- Left -->
    <!-- End Example Code -->
    <div class="container">
      <div class="text-center">
          <h2 class="section-heading text-uppercase">INFORMACION</h2>
          
      </div>
    <div class="row row-cols-1 row-cols-md-2 g-4">
    <div class="col">
      <div class="card">
        <img src="/principal/img/cargando.gif" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="/principal/img/cargando.gif" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="/principal/img/cargando.gif" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="/principal/img/cargando.gif" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        </div>
      </div>
    </div>
  </div>
        <!-- Left -->
        <hr class="hr hr-blurry" />
        <!-- Left -->

        <!-- Right -->
        <div>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-facebook-f"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-twitter"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-google"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-instagram"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-linkedin"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-github"></i>
          </a>
        </div>
        <!-- Right -->
      </section>
      <!-- Section: Social media -->

      <!-- Section: Links  -->
      <section class="p-3 mb-2 bg-secondary text-white">
        <div class="container text-center text-md-start mt-5">
          <!-- Grid row -->
          <div class="row mt-3">
            <!-- Grid column -->
            <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
              <!-- Content -->
              <h6 class="text-uppercase fw-bold mb-4">
                <i class="fas fa-gem me-3"></i>Company name
              </h6>
              <img
                src="https://i.pinimg.com/564x/6d/3b/48/6d3b480a75c514692a4ba4e222d2031f.jpg"
                class="img-thumbnail"
                alt="presidente"
              />
              <p>
                Here you can use rows and columns to organize your footer
                content. Lorem ipsum dolor sit amet, consectetur adipisicing
                elit.
              </p>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold mb-4">Products</h6>
              <p>
                <a href="#!" class="text-reset">Angular</a>
              </p>
              <p>
                <a href="#!" class="text-reset">React</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Vue</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Laravel</a>
              </p>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold mb-4">Useful links</h6>
              <p>
                <a href="#!" class="text-reset">Pricing</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Settings</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Orders</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Help</a>
              </p>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
              <p><i class="fas fa-home me-3"></i> New York, NY 10012, US</p>
              <p>
                <i class="fas fa-envelope me-3"></i>
                info@example.com
              </p>
              <p><i class="fas fa-phone me-3"></i> + 01 234 567 88</p>
              <p><i class="fas fa-print me-3"></i> + 01 234 567 89</p>
            </div>
            <!-- Grid column -->
          </div>
          <!-- Grid row -->
        </div>
      </section>
      <!-- Section: Links  -->

      <!-- Copyright -->
      <div
        class="text-center p-4 p-3 mb-2 bg-success text-white""
        style="background-color: rgba(0, 0, 0, 0.05)"
      >
        © 2021 Copyright:
        <a class="text-reset fw-bold" href="https://mdbootstrap.com/"
          >MDBootstrap.com</a
        >
      </div>
      <!-- Copyright -->
    </footer>
    <!-- Footer -->
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\principal\resources\views/tempplate.blade.php ENDPATH**/ ?>